import { Star, MapPin, Phone, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function ServiceCard({ service }) {
  const navigate = useNavigate();
  
  const handleViewService = () => {
    navigate(`/service/${service.id}`, { state: { service } });
  };

  return (
    <div className="glass-panel animate-fade-in" style={{ padding: '2rem', display: 'flex', flexDirection: 'column', height: '100%' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1.5rem' }}>
        <div>
          <h3 style={{ fontSize: '1.5rem', marginBottom: '0.5rem', fontWeight: 'bold' }}>{service.name}</h3>
          <span style={{ 
            display: 'inline-block', 
            padding: '0.3rem 0.8rem', 
            backgroundColor: 'var(--surface-hover)', 
            borderRadius: '999px',
            fontSize: '0.875rem',
            color: 'var(--primary)',
            fontWeight: '500'
          }}>
            {service.type}
          </span>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: '0.5rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', color: '#f59e0b', fontWeight: 'bold', fontSize: '1.1rem' }}>
            <Star size={20} fill="currentColor" /> {service.rating}
          </div>
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '-0.2rem', fontWeight: '500' }}>Starts from</div>
            <div style={{ fontSize: '1.5rem', fontWeight: '800', color: 'var(--text-color)' }}>
              ₹{service.price}
            </div>
          </div>
        </div>
      </div>

      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '0.75rem', marginBottom: '2rem', color: 'var(--text-muted)' }}>
        <p style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', fontSize: '1rem' }}>
          <MapPin size={18} className="text-gradient" /> {service.location}
        </p>
        <p style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', fontSize: '1rem' }}>
          <Phone size={18} className="text-gradient" /> {service.phone}
        </p>
      </div>

      <div style={{ marginTop: 'auto', borderTop: '1px solid var(--border-color)', paddingTop: '1.5rem' }}>
        <button 
          className="btn btn-primary" 
          onClick={handleViewService}
          style={{ width: '100%', padding: '0.75rem', display: 'flex', justifyContent: 'center', gap: '0.5rem' }}
        >
          View and Book Service <ArrowRight size={20} />
        </button>
      </div>
    </div>
  );
}
