import { useState, useContext, useEffect } from 'react';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import { Star, MapPin, Phone, Calendar, Clock, CreditCard, ArrowLeft, ShieldCheck } from 'lucide-react';

export default function ServiceDetails() {
  const location = useLocation();
  const navigate = useNavigate();
  const { id } = useParams();
  const { user } = useContext(AuthContext);

  const [bookingDate, setBookingDate] = useState('');
  const [timeSlot, setTimeSlot] = useState('');
  const [message, setMessage] = useState('');

  const service = location.state?.service;

  useEffect(() => {
    if (!service) {
      navigate('/');
    }
  }, [service, navigate]);

  if (!service) return null;

  // Times from 9 AM to 11 PM
  const timeSlots = Array.from({ length: 15 }, (_, i) => {
    const hour = i + 9;
    const period = hour >= 12 ? 'PM' : 'AM';
    const hour12 = hour > 12 ? hour - 12 : hour;
    return `${hour12 === 0 ? 12 : hour12}:00 ${period} - ${hour12 === 11 ? 12 : (hour12 === 12 ? 1 : hour12 + 1)}:00 ${hour + 1 >= 12 ? 'PM' : 'AM'}`;
  });

  const handleCheckoutRedirect = () => {
    if (!user) {
      navigate('/login');
      return;
    }
    if (!bookingDate || !timeSlot) {
      setMessage('Please select Date and Time Slot before continuing!');
      return;
    }
    
    navigate('/payment', { 
      state: { 
        service: service, 
        bookingDate: bookingDate, 
        timeSlot: timeSlot 
      } 
    });
  };

  return (
    <div className="animate-fade-in" style={{ maxWidth: '900px', margin: '0 auto', paddingBottom: '4rem' }}>
      <button 
        onClick={() => navigate(-1)} 
        className="btn btn-outline" 
        style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', marginBottom: '2rem', padding: '0.5rem 1rem' }}
      >
        <ArrowLeft size={18} /> Back to Services
      </button>

      <div className="grid grid-cols-2" style={{ gap: '2rem' }}>
        {/* Service Details Panel */}
        <div className="glass-panel" style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1.5rem' }}>
            <div>
              <h1 style={{ fontSize: '2rem', marginBottom: '0.5rem', fontWeight: 'bold' }}>{service.name}</h1>
              <span style={{ 
                display: 'inline-block', 
                padding: '0.3rem 0.8rem', 
                backgroundColor: 'var(--surface-hover)', 
                borderRadius: '999px',
                fontSize: '0.875rem',
                color: 'var(--primary)',
                fontWeight: '500'
              }}>
                {service.type}
              </span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', color: '#f59e0b', fontWeight: 'bold', fontSize: '1.2rem' }}>
              <Star size={24} fill="currentColor" /> {service.rating}
            </div>
          </div>

          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '1rem', color: 'var(--text-color)', marginBottom: '2rem' }}>
            <p style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', fontSize: '1.1rem' }}>
              <MapPin size={20} className="text-gradient" /> {service.location}
            </p>
            <p style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', fontSize: '1.1rem' }}>
              <Phone size={20} className="text-gradient" /> {service.phone}
            </p>
            <p style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', fontSize: '1.1rem' }}>
               <ShieldCheck size={20} className="text-gradient" /> Verified Professional
            </p>
          </div>
          
          <div style={{ padding: '1rem', backgroundColor: 'var(--surface-hover)', borderRadius: '0.5rem', marginTop: 'auto' }}>
            <span style={{ fontSize: '1rem', color: 'var(--text-muted)' }}>Base Charge</span>
            <div style={{ fontSize: '2rem', fontWeight: '800', color: 'var(--primary)' }}>
              ₹{service.price}
            </div>
          </div>
        </div>

        {/* Booking Panel */}
        <div className="glass-panel" style={{ display: 'flex', flexDirection: 'column' }}>
          <h2 style={{ fontSize: '1.5rem', marginBottom: '1.5rem', fontWeight: 'bold', borderBottom: '1px solid var(--border-color)', paddingBottom: '1rem' }}>Book this Service</h2>
          
          {message && (
            <div style={{
              color: '#ef4444',
              backgroundColor: '#fef2f2',
              padding: '0.75rem',
              borderRadius: '0.5rem',
              fontSize: '0.9rem',
              fontWeight: '500',
              marginBottom: '1.5rem',
              textAlign: 'center',
              border: '1px solid #f87171'
            }}>
              {message}
            </div>
          )}
          
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem', flex: 1 }}>
            <div>
              <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>Select Date</label>
              <div style={{ position: 'relative' }}>
                <Calendar size={20} style={{ position: 'absolute', left: '1rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
                <input 
                  type="date" 
                  className="input-field" 
                  value={bookingDate}
                  onChange={e => { setBookingDate(e.target.value); setMessage(''); }}
                  style={{ paddingLeft: '3rem', width: '100%', fontSize: '1.1rem', padding: '1rem 1rem 1rem 3rem' }}
                  min={new Date().toISOString().split('T')[0]}
                />
              </div>
            </div>

            <div>
              <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>Select Time Slot</label>
              <div style={{ position: 'relative' }}>
                <Clock size={20} style={{ position: 'absolute', left: '1rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
                <select 
                  className="input-field" 
                  value={timeSlot} 
                  onChange={e => { setTimeSlot(e.target.value); setMessage(''); }} 
                  style={{ paddingLeft: '3rem', width: '100%', fontSize: '1.1rem', padding: '1rem 1rem 1rem 3rem' }}
                >
                  <option value="" disabled>Select Time</option>
                  {timeSlots.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
            </div>

            <button 
              className="btn btn-primary" 
              onClick={handleCheckoutRedirect}
              style={{ width: '100%', padding: '1rem', display: 'flex', justifyContent: 'center', gap: '0.5rem', fontSize: '1.1rem', marginTop: 'auto' }}
            >
              <CreditCard size={22} /> Proceed to Checkout
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
