import { useState, useEffect, useContext } from 'react';
import { Navigate, Link } from 'react-router-dom';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';
import { Trash2, Users, Receipt, Briefcase, AlertCircle, RefreshCw, MessageCircle } from 'lucide-react';

export default function Admin() {
  const { user, token } = useContext(AuthContext);
  const [activeTab, setActiveTab] = useState('bookings');
  const [services, setServices] = useState([]);
  const [allBookings, setAllBookings] = useState([]);
  const [formData, setFormData] = useState({ name: '', type: '', phone: '', location: '', rating: '', price: '' });
  const [message, setMessage] = useState('');

  useEffect(() => {
    if (user?.role === 'admin') {
      fetchServices();
      fetchAllBookings();
    }
  }, [user]);

  const fetchServices = async () => {
    const res = await axios.get('http://localhost:5000/api/services');
    setServices(res.data);
  };

  const fetchAllBookings = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/admin/bookings', { headers: { Authorization: `Bearer ${token}` } });
      setAllBookings(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  const handleUpdateStatus = async (bookingId, newStatus) => {
    try {
      await axios.put(`http://localhost:5000/api/admin/bookings/${bookingId}`, { status: newStatus }, { headers: { Authorization: `Bearer ${token}` } });
      fetchAllBookings();
    } catch (err) {
      console.error("Failed to update status");
    }
  };

  const handleChange = (e) => setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleAddService = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/api/services', {
        name: formData.name, type: formData.type, phone: formData.phone, 
        location: formData.location, rating: parseFloat(formData.rating), price: parseInt(formData.price || 500)
      }, { headers: { Authorization: `Bearer ${token}` } });
      setMessage('Service added successfully');
      setFormData({ name: '', type: '', phone: '', location: '', rating: '', price: '' });
      fetchServices();
      setTimeout(() => setMessage(''), 3000);
    } catch (err) {
      setMessage('Failed to add service');
    }
  };

  const handleDeleteService = async (id) => {
    if (!window.confirm('Delete this service entirely?')) return;
    try {
      await axios.delete(`http://localhost:5000/api/services/${id}`, { headers: { Authorization: `Bearer ${token}` } });
      fetchServices();
    } catch (err) {
      console.error(err);
    }
  };

  if (!user || user.role !== 'admin') {
    return (
      <div className="animate-fade-in" style={{ display: 'flex', justifyContent: 'center', padding: '6rem 1rem' }}>
        <div className="glass-panel" style={{ textAlign: 'center', maxWidth: '400px' }}>
          <AlertCircle size={48} className="text-gradient" style={{ margin: '0 auto 1rem' }} />
          <h2 style={{ fontSize: '2rem', marginBottom: '1rem', color: '#ef4444' }}>Access Denied</h2>
          <p style={{ color: 'var(--text-muted)' }}>Only registered administrators can view the Admin Panel.</p>
          <Link to="/" className="btn btn-primary" style={{ marginTop: '2rem' }}>Return Home</Link>
        </div>
      </div>
    );
  }

  const completedBookings = allBookings.filter(b => b.status === "completed" || b.status === "Completed");
  const totalMoney = completedBookings.reduce((sum, b) => sum + (b.price || 0), 0);
  const totalFeedbackCount = allBookings.filter(b => b.customer_feedback).length;

  return (
    <div className="animate-fade-in" style={{ paddingBottom: '4rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
        <div>
          <h1 style={{ fontSize: '2.5rem', marginBottom: '0.25rem' }}>Admin Control Center</h1>
          <p style={{ color: 'var(--text-muted)' }}>Real-time customer analytics and ledger.</p>
        </div>
        <div style={{ display: 'flex', gap: '1rem' }}>
           <button className={`btn ${activeTab === 'bookings' ? 'btn-primary' : 'btn-outline'}`} onClick={() => setActiveTab('bookings')}>Bookings Vault</button>
           <button className={`btn ${activeTab === 'services' ? 'btn-primary' : 'btn-outline'}`} onClick={() => setActiveTab('services')}>Service Registry</button>
        </div>
      </div>

      <div style={{ marginBottom: '2.5rem' }}>
        <div className="glass-panel" style={{ padding: '2.5rem', textAlign: 'center' }}>
            <p style={{ color: 'var(--text-muted)', fontSize: '1.25rem', marginBottom: '0.5rem', fontWeight: '500' }}>Total Realized Revenue</p>
            <h3 style={{ fontSize: '4.5rem', fontWeight: '900', color: '#10b981', margin: 0, textShadow: '0 4px 20px rgba(16, 185, 129, 0.2)' }}>₹{totalMoney.toLocaleString()}</h3>
        </div>
      </div>
      
      {activeTab === 'bookings' && (
        <div className="glass-panel" style={{ padding: 0, overflow: 'hidden' }}>
          <div style={{ padding: '1.5rem', borderBottom: '1px solid var(--border-color)', backgroundColor: 'var(--surface-hover)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
             <h2 style={{ fontSize: '1.5rem', margin: 0 }}>Customer Order Ledger</h2>
             <button onClick={fetchAllBookings} className="btn" style={{ padding: '0.5rem', color: 'var(--text-muted)' }} title="Refresh Bookings"><RefreshCw size={20}/></button>
          </div>
          <div style={{ overflowX: 'auto', maxHeight: '700px' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', minWidth: '900px' }}>
              <thead style={{ backgroundColor: 'var(--bg-color)', position: 'sticky', top: 0, zIndex: 10 }}>
                <tr>
                  <th style={{ padding: '1.25rem 1rem', borderBottom: '1px solid var(--border-color)', color: 'var(--text-muted)' }}>Customer</th>
                  <th style={{ padding: '1.25rem 1rem', borderBottom: '1px solid var(--border-color)', color: 'var(--text-muted)' }}>Service Requested</th>
                  <th style={{ padding: '1.25rem 1rem', borderBottom: '1px solid var(--border-color)', color: 'var(--text-muted)' }}>Appointment</th>
                  <th style={{ padding: '1.25rem 1rem', borderBottom: '1px solid var(--border-color)', color: 'var(--text-muted)' }}>Value</th>
                  <th style={{ padding: '1.25rem 1rem', borderBottom: '1px solid var(--border-color)', color: 'var(--text-muted)' }}>Action & Feedback</th>
                </tr>
              </thead>
              <tbody>
                {allBookings.map(b => (
                  <tr key={b.id} style={{ borderBottom: '1px solid var(--border-color)' }} className="hover:bg-surface-hover">
                    <td style={{ padding: '1rem', verticalAlign: 'top' }}>
                      <div style={{ fontWeight: 'bold' }}>{b.customer_name}</div>
                      <div style={{ fontSize: '0.875rem', color: 'var(--text-muted)' }}>{b.customer_email}</div>
                    </td>
                    <td style={{ padding: '1rem', verticalAlign: 'top' }}>{b.service_name}</td>
                    <td style={{ padding: '1rem', verticalAlign: 'top' }}>
                      <div>{new Date(b.date).toLocaleDateString()}</div>
                      <div style={{ fontSize: '0.875rem', color: 'var(--primary)' }}>{b.time_slot}</div>
                    </td>
                    <td style={{ padding: '1rem', fontWeight: 'bold', color: '#10b981', verticalAlign: 'top' }}>₹{b.price}</td>
                    <td style={{ padding: '1rem', verticalAlign: 'top' }}>
                      <select 
                        className="input-field" 
                        value={b.status}
                        onChange={(e) => handleUpdateStatus(b.id, e.target.value)}
                        style={{ 
                          padding: '0.5rem', marginBottom: '0.5rem',
                          backgroundColor: b.status === 'Completed' || b.status === 'completed' ? '#ecfdf5' : 'var(--bg-color)',
                          color: b.status === 'Completed' || b.status === 'completed' ? '#10b981' : 'var(--text-color)',
                          borderColor: b.status === 'Completed' || b.status === 'completed' ? '#34d399' : 'var(--border-color)'
                        }}
                      >
                        <option value="pending">Pending Worker</option>
                        <option value="In Progress">In Progress</option>
                        <option value="Completed">Verified Completed</option>
                        <option value="Cancelled">Cancelled</option>
                      </select>
                      
                      {/* Customer Feedback visualizer */}
                      {b.customer_feedback && (
                        <div style={{ marginTop: '0.5rem', padding: '0.5rem', backgroundColor: 'var(--bg-color)', borderLeft: '3px solid var(--primary)', borderRadius: '0 0.5rem 0.5rem 0' }}>
                           <div style={{ color: '#f59e0b', fontSize: '0.8rem', marginBottom: '0.2rem' }}>★ {b.customer_rating}.0 Feedback</div>
                           <div style={{ fontSize: '0.85rem', fontStyle: 'italic', color: 'var(--text-muted)' }}>"{b.customer_feedback}"</div>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {allBookings.length === 0 && <div style={{ padding: '4rem', textAlign: 'center', color: 'var(--text-muted)' }}>No customer bookings yet.</div>}
          </div>
        </div>
      )}

      {/* Services tab intact strictly for adding new service nodes */}
      {activeTab === 'services' && (
        <div className="grid" style={{ gridTemplateColumns: 'minmax(0, 1fr) minmax(0, 2fr)', alignItems: 'start', gap: '2rem' }}>
          <div className="glass-panel" style={{ position: 'sticky', top: '5rem' }}>
            <h2 style={{ fontSize: '1.5rem', marginBottom: '1.5rem' }}>Add Service Node</h2>
            {message && <div style={{ marginBottom: '1.5rem', padding: '0.75rem', backgroundColor: '#ecfdf5', color: '#10b981', borderRadius: '0.5rem' }}>{message}</div>}
            
            <form onSubmit={handleAddService} style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
              <div>
                <input type="text" name="name" className="input-field" value={formData.name} onChange={handleChange} required placeholder="Service/Worker Name" />
              </div>
              <div>
                <input type="text" name="type" className="input-field" value={formData.type} onChange={handleChange} required placeholder="Category (Plumber etc)" />
              </div>
              <div>
                <input type="text" name="phone" className="input-field" value={formData.phone} onChange={handleChange} required placeholder="Phone number" />
              </div>
              <div>
                <input type="text" name="location" className="input-field" value={formData.location} onChange={handleChange} required placeholder="Location Area" />
              </div>
              <div style={{ display: 'flex', gap: '1rem' }}>
                <input type="number" step="0.1" name="rating" className="input-field" value={formData.rating} onChange={handleChange} required placeholder="Rating (0-5)" style={{ flex: 1 }} />
                <input type="number" name="price" className="input-field" value={formData.price} onChange={handleChange} required placeholder="Base Price ₹" style={{ flex: 1 }} />
              </div>
              <button type="submit" className="btn btn-primary" style={{ width: '100%' }}>Register Service</button>
            </form>
          </div>

          <div className="glass-panel" style={{ overflow: 'hidden', padding: 0 }}>
             <div style={{ maxHeight: '600px', overflowY: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
                <tbody>
                  {services.map(service => (
                    <tr key={service.id} style={{ borderBottom: '1px solid var(--border-color)' }}>
                      <td style={{ padding: '1.25rem 1rem' }}>
                        <div style={{ fontWeight: 'bold' }}>{service.name}</div>
                        <div style={{ fontSize: '0.875rem', color: 'var(--text-muted)' }}>{service.location}</div>
                      </td>
                      <td style={{ padding: '1.25rem 1rem' }}><span style={{ backgroundColor: 'var(--surface-hover)', padding: '0.2rem 0.5rem', borderRadius: '4px', fontSize: '0.875rem' }}>{service.type}</span></td>
                      <td style={{ padding: '1.25rem 1rem', color: '#10b981', fontWeight: 'bold' }}>₹{service.price}</td>
                      <td style={{ padding: '1.25rem 1rem', textAlign: 'right' }}>
                        <button onClick={() => handleDeleteService(service.id)} style={{ color: '#ef4444', padding: '0.5rem' }}><Trash2 size={20} /></button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
