import { useState, useEffect } from 'react';
import axios from 'axios';
import { Search, Filter, X } from 'lucide-react';
import ServiceCard from '../components/ServiceCard';
import MapWidget from '../components/MapWidget';

export default function Home() {
  const [services, setServices] = useState([]);
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(true);

  // Filter States
  const [showFilters, setShowFilters] = useState(false);
  const [filterPlace, setFilterPlace] = useState('');
  const [maxPrice, setMaxPrice] = useState(2500);
  const [sortByNearby, setSortByNearby] = useState(false);

  useEffect(() => {
    fetchServices();
  }, []);

  const fetchServices = async (searchQuery = '') => {
    setLoading(true);
    try {
      const url = searchQuery 
        ? `http://localhost:5000/api/services?q=${encodeURIComponent(searchQuery)}`
        : 'http://localhost:5000/api/services';
      const res = await axios.get(url);
      setServices(res.data);
    } catch (err) {
      console.error('Failed to fetch services', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e) => {
    e.preventDefault();
    fetchServices(query);
  };

  const filteredServices = services.filter(s => {
    if (filterPlace && !s.location.toLowerCase().includes(filterPlace.toLowerCase())) return false;
    if (s.price > maxPrice) return false;
    return true;
  }).sort((a, b) => {
    if (sortByNearby) {
      // Default reference map center (India center)
      const lat = 20.5937, lng = 78.9629;
      const distA = Math.pow(a.lat - lat, 2) + Math.pow(a.lng - lng, 2);
      const distB = Math.pow(b.lat - lat, 2) + Math.pow(b.lng - lng, 2);
      return distA - distB;
    }
    
    // Default sort: Prioritize Hyderabad locations
    const aIsHyd = a.location.toLowerCase().includes('hyderabad');
    const bIsHyd = b.location.toLowerCase().includes('hyderabad');
    
    if (aIsHyd && !bIsHyd) return -1;
    if (!aIsHyd && bIsHyd) return 1;
    return 0;
  });

  return (
    <div className="animate-fade-in">
      <section style={{ textAlign: 'center', margin: '3rem 0 4rem' }}>
        <h1 style={{ fontSize: '3.5rem', marginBottom: '1.25rem', fontWeight: '800' }}>
          Find Local <span className="text-gradient">Experts</span> Fast.
        </h1>
        <p style={{ fontSize: '1.25rem', color: 'var(--text-muted)', marginBottom: '2.5rem', maxWidth: '700px', margin: '0 auto 2.5rem' }}>
          Book elite electricians, reliable plumbers, and premium mechanics anywhere in India. View prices and select your exact time slot right now.
        </p>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', maxWidth: '800px', margin: '0 auto' }}>
          <form onSubmit={handleSearch} style={{ display: 'flex', gap: '0.5rem', width: '100%' }}>
            <div style={{ position: 'relative', flex: 1 }}>
              <Search size={22} style={{ position: 'absolute', left: '1.25rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
              <input
                type="text"
                placeholder="Search for a service area or type..."
                className="input-field"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                style={{ paddingLeft: '3.5rem', paddingRight: '3.5rem', height: '100%', fontSize: '1.1rem' }}
              />
              {query && (
                <button
                  type="button"
                  onClick={() => {
                    setQuery('');
                    fetchServices('');
                  }}
                  style={{ 
                    position: 'absolute', right: '1rem', top: '50%', transform: 'translateY(-50%)', 
                    color: 'var(--text-muted)', background: 'transparent', border: 'none', cursor: 'pointer', 
                    padding: '0.25rem', display: 'flex', alignItems: 'center' 
                  }}
                  title="Clear search"
                >
                  <X size={20} />
                </button>
              )}
            </div>
            <button type="submit" className="btn btn-primary" style={{ padding: '1rem 2.5rem', fontSize: '1.1rem' }}>Search</button>
            <button 
              type="button" 
              className="btn btn-outline" 
              onClick={() => setShowFilters(!showFilters)}
              style={{ padding: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}
            >
              <Filter size={20} />
              Filter
            </button>
          </form>

          {showFilters && (
            <div className="glass-panel animate-fade-in" style={{ display: 'flex', gap: '2rem', padding: '1.5rem', textAlign: 'left', alignItems: 'flex-end', flexWrap: 'wrap', marginTop: '0.5rem' }}>
              <div style={{ flex: 1, minWidth: '200px' }}>
                <label style={{ display: 'block', fontSize: '0.9rem', marginBottom: '0.5rem', fontWeight: 'bold' }}>Place / City / Area</label>
                <input 
                  type="text" 
                  className="input-field" 
                  placeholder="e.g. Delhi, Bandra, Bangalore..." 
                  value={filterPlace} 
                  onChange={e => setFilterPlace(e.target.value)} 
                  style={{ width: '100%', padding: '0.65rem 1rem' }}
                />
              </div>

              <div style={{ flex: 1, minWidth: '200px' }}>
                <label style={{ display: 'block', fontSize: '0.9rem', marginBottom: '0.5rem', fontWeight: 'bold' }}>Max Price: ₹{maxPrice === 2500 ? 'Any' : maxPrice}</label>
                <input 
                  type="range" 
                  min="100" 
                  max="2500" 
                  step="100"
                  value={maxPrice} 
                  onChange={e => setMaxPrice(parseInt(e.target.value))}
                  style={{ width: '100%', accentColor: 'var(--primary)', height: '2.5rem', cursor: 'pointer' }}
                />
              </div>

              <div style={{ display: 'flex', alignItems: 'center', minWidth: '150px', height: '2.8rem' }}>
                <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer', fontWeight: 'bold' }}>
                  <input 
                    type="checkbox" 
                    checked={sortByNearby} 
                    onChange={e => setSortByNearby(e.target.checked)}
                    style={{ width: '1.2rem', height: '1.2rem', accentColor: 'var(--primary)' }}
                  />
                  Sort by Nearby
                </label>
              </div>
            </div>
          )}
        </div>
      </section>

      <section>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2.5rem' }}>
          <h2 style={{ fontSize: '2.25rem', fontWeight: 'bold' }}>Available Providers</h2>
        </div>

        {loading ? (
          <div style={{ textAlign: 'center', padding: '5rem', color: 'var(--text-muted)', fontSize: '1.2rem' }}>Loading verified providers...</div>
        ) : filteredServices.length > 0 ? (
          /* Notice we changed layout from 4 cols max to 2 cols for much more beautifully spacious cards */
          <div className="grid grid-cols-2" style={{ gap: '2rem' }}>
            {filteredServices.map(service => (
              <ServiceCard key={service.id} service={service} />
            ))}
          </div>
        ) : (
          <div style={{ textAlign: 'center', padding: '5rem', color: 'var(--text-muted)', background: 'var(--surface)', borderRadius: '1.5rem', fontSize: '1.2rem' }}>
            No services found matching your criteria. Try adjusting your search!
          </div>
        )}
      </section>
      
      <section style={{ marginTop: '5rem' }}>
        <h2 style={{ fontSize: '2.25rem', marginBottom: '2rem', fontWeight: 'bold' }}>Interactive Coverage Boundaries</h2>
        <div style={{ width: '100%', height: '500px', borderRadius: '1.5rem', overflow: 'hidden', boxShadow: 'var(--shadow-lg)' }}>
           <MapWidget services={filteredServices} />
        </div>
      </section>
    </div>
  );
}
