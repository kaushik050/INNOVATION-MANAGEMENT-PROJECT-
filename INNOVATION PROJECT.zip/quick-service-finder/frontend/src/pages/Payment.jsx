import { useState, useContext, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';
import { CreditCard, CheckCircle, ShieldCheck, Wallet, ArrowRight } from 'lucide-react';

export default function Payment() {
  const { user, token } = useContext(AuthContext);
  const location = useLocation();
  const navigate = useNavigate();
  
  const [selectedMethod, setSelectedMethod] = useState('');
  const [processing, setProcessing] = useState(false);
  const [success, setSuccess] = useState(false);

  const bookingData = location.state;

  // Protect route
  useEffect(() => {
    if (!user) navigate('/login');
    if (!bookingData) navigate('/');
  }, [user, bookingData, navigate]);

  if (!bookingData) return null;

  const handlePayment = async () => {
    if (!selectedMethod) {
      alert("Please select a payment method.");
      return;
    }
    
    setProcessing(true);
    
    // Simulate real bank processing for 2 seconds
    setTimeout(async () => {
      try {
        await axios.post(
          'http://localhost:5000/api/bookings',
          { 
            service_id: bookingData.service.id, 
            date: bookingData.bookingDate, 
            time_slot: bookingData.timeSlot, 
            payment_method: selectedMethod 
          },
          { headers: { Authorization: `Bearer ${token}` } }
        );
        
        setSuccess(true);
        setTimeout(() => {
          navigate('/dashboard');
        }, 1500);
      } catch (err) {
        alert('Payment failed or booking rejected.');
        setProcessing(false);
      }
    }, 2000);
  };

  const paymentMethods = [
    { id: 'Amazon Pay', name: 'Amazon Pay', icon: '🛍️' },
    { id: 'UPI', name: 'UPI (GPay, PhonePe, Paytm)', icon: '📱' },
    { id: 'Debit Card', name: 'Debit / Credit Card', icon: '💳' },
    { id: 'Net Banking', name: 'Net Banking', icon: '🏦' }
  ];

  return (
    <div className="animate-fade-in" style={{ maxWidth: '800px', margin: '2rem auto', padding: '0 1rem' }}>
      <h1 style={{ fontSize: '2.5rem', marginBottom: '0.5rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
        <ShieldCheck className="text-gradient" size={36} /> Secure Checkout
      </h1>
      <p style={{ color: 'var(--text-muted)', marginBottom: '2rem' }}>Complete your payment to confirm your booking.</p>

      {success ? (
        <div className="glass-panel" style={{ textAlign: 'center', padding: '4rem 2rem' }}>
          <CheckCircle size={64} style={{ color: '#10b981', margin: '0 auto 1.5rem' }} />
          <h2 style={{ fontSize: '2rem', marginBottom: '1rem', color: '#10b981' }}>Payment Successful!</h2>
          <p style={{ fontSize: '1.2rem', color: 'var(--text-color)' }}>Your booking with {bookingData.service.name} is confirmed.</p>
          <p style={{ color: 'var(--text-muted)', marginTop: '1rem' }}>Redirecting to your dashboard...</p>
        </div>
      ) : (
        <div className="grid grid-cols-2" style={{ gap: '2rem', minHeight: '400px' }}>
          
          {/* Order Summary */}
          <div className="glass-panel" style={{ height: 'fit-content' }}>
            <h2 style={{ fontSize: '1.25rem', marginBottom: '1.5rem', borderBottom: '1px solid var(--border-color)', paddingBottom: '1rem' }}>Order Summary</h2>
            
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', marginBottom: '2rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ color: 'var(--text-muted)' }}>Service Provider</span>
                <span style={{ fontWeight: '600' }}>{bookingData.service.name}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ color: 'var(--text-muted)' }}>Location</span>
                <span style={{ textAlign: 'right' }}>{bookingData.service.location}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ color: 'var(--text-muted)' }}>Date</span>
                <span>{new Date(bookingData.bookingDate).toLocaleDateString()}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ color: 'var(--text-muted)' }}>Time Slot</span>
                <span>{bookingData.timeSlot}</span>
              </div>
            </div>

            <div style={{ borderTop: '1px dashed var(--border-color)', paddingTop: '1.5rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: '1.25rem', fontWeight: '500' }}>Total Amount</span>
              <span style={{ fontSize: '2rem', fontWeight: '800', color: 'var(--primary)' }}>₹{bookingData.service.price}</span>
            </div>
          </div>

          {/* Payment Selection */}
          <div className="glass-panel" style={{ display: 'flex', flexDirection: 'column' }}>
            <h2 style={{ fontSize: '1.25rem', marginBottom: '1.5rem' }}>Select Payment Method</h2>
            
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', flex: 1 }}>
              {paymentMethods.map(method => (
                <label 
                  key={method.id}
                  style={{ 
                    display: 'flex', alignItems: 'center', gap: '1rem', padding: '1rem', 
                    border: `2px solid ${selectedMethod === method.id ? 'var(--primary)' : 'var(--border-color)'}`,
                    borderRadius: '0.5rem', cursor: 'pointer', transition: 'all 0.2s',
                    backgroundColor: selectedMethod === method.id ? 'rgba(79, 70, 229, 0.05)' : 'transparent'
                  }}
                  className="hover:bg-surface-hover"
                >
                  <input 
                    type="radio" 
                    name="payment_method" 
                    value={method.id} 
                    checked={selectedMethod === method.id}
                    onChange={(e) => setSelectedMethod(e.target.value)}
                    style={{ width: '1.2rem', height: '1.2rem', accentColor: 'var(--primary)' }}
                  />
                  <span style={{ fontSize: '1.5rem' }}>{method.icon}</span>
                  <span style={{ fontSize: '1.1rem', fontWeight: '500' }}>{method.name}</span>
                </label>
              ))}
            </div>

            <button 
              className="btn btn-primary" 
              onClick={handlePayment}
              disabled={processing || !selectedMethod}
              style={{ width: '100%', padding: '1rem', fontSize: '1.2rem', marginTop: '2rem' }}
            >
              {processing ? (
                 <>Processing Transaction...</>
              ) : (
                <>Pay ₹{bookingData.service.price} & Confirm <ArrowRight size={20}/></>
              )}
            </button>
          </div>

        </div>
      )}
    </div>
  );
}
