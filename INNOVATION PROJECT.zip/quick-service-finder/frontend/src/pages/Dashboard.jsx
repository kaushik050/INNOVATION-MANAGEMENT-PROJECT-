import { useState, useEffect, useContext } from 'react';
import { Navigate } from 'react-router-dom';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';
import { Calendar, Clock, CheckCircle, CreditCard, Loader, Star, MessageSquare, Trash2 } from 'lucide-react';


export default function Dashboard() {
  const { user, token } = useContext(AuthContext);
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  
  // Feedback States per booking
  const [feedbackInputs, setFeedbackInputs] = useState({});

  useEffect(() => {
    if (user && token) {
      fetchBookings();
    }
  }, [user, token]);

  const fetchBookings = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/bookings', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setBookings(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleFeedbackChange = (bookingId, field, value) => {
    setFeedbackInputs(prev => ({
      ...prev,
      [bookingId]: { ...prev[bookingId], [field]: value }
    }));
  };

  const submitFeedback = async (bookingId) => {
    const input = feedbackInputs[bookingId];
    if (!input || !input.rating || !input.feedback) {
      alert("Please provide both a star rating and a comment!");
      return;
    }
    
    try {
      await axios.put(`http://localhost:5000/api/bookings/${bookingId}/feedback`, {
        rating: input.rating,
        feedback: input.feedback
      }, { headers: { Authorization: `Bearer ${token}` } });
      
      // Refresh to lock feedback in
      fetchBookings();
    } catch (err) {
      console.error("Failed to submit feedback", err);
    }
  };

  const deleteBooking = async (bookingId) => {
    if (!window.confirm("Are you sure you want to delete this booking?")) return;
    try {
      await axios.delete(`http://localhost:5000/api/bookings/${bookingId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      fetchBookings();
    } catch (err) {
      console.error("Failed to delete booking", err);
      alert("Error deleting booking");
    }
  };

  if (!user) {
    return <Navigate to="/login" />;
  }

  return (
    <div className="animate-fade-in" style={{ maxWidth: '900px', margin: '0 auto', paddingBottom: '4rem' }}>
      <h1 style={{ fontSize: '2.5rem', marginBottom: '2rem' }}>My Dashboard</h1>
      
      <div className="glass-panel" style={{ marginBottom: '2.5rem' }}>
        <h2 style={{ fontSize: '1.5rem', marginBottom: '0.5rem' }}>Welcome back, {user.name}!</h2>
        <p style={{ color: 'var(--text-muted)' }}>Manage and track your service appointments below.</p>
      </div>

      <h2 style={{ fontSize: '1.75rem', margin: '0 0 1.5rem' }}>My Bookings</h2>
      
      {loading ? (
        <p style={{ color: 'var(--text-muted)' }}>Loading appointments...</p>
      ) : bookings.length > 0 ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          {bookings.map(booking => {
            const isCompleted = booking.status.toLowerCase() === 'completed';
            const hasFeedback = !!booking.customer_feedback;
            const fbInput = feedbackInputs[booking.id] || { rating: 0, feedback: '' };

            return (
              <div key={booking.id} className="glass-panel" style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                      <h3 style={{ fontSize: '1.5rem', marginBottom: '0.25rem', fontWeight: 'bold' }}>{booking.service_name}</h3>
                      <button 
                        onClick={() => deleteBooking(booking.id)}
                        className="btn"
                        style={{ padding: '0.25rem', color: '#ef4444', backgroundColor: 'transparent', border: 'none' }}
                        title="Delete Booking"
                      >
                        <Trash2 size={20} />
                      </button>
                    </div>
                    <p style={{ color: 'var(--primary)', fontWeight: '500', marginBottom: '1rem' }}>
                      Base Charge: ₹{booking.price}
                    </p>
                    <div style={{ display: 'flex', gap: '1.5rem', color: 'var(--text-muted)', fontSize: '0.9rem' }}>
                      <span style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                        <CreditCard size={16} /> {booking.payment_method}
                      </span>
                    </div>
                  </div>
                  <div style={{ textAlign: 'right', backgroundColor: 'var(--surface-hover)', padding: '1rem', borderRadius: '0.75rem' }}>
                    <p style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: '0.5rem', fontWeight: 'bold', fontSize: '1.1rem', marginBottom: '0.25rem' }}>
                      <Calendar size={18} className="text-gradient" /> {new Date(booking.date).toLocaleDateString()}
                    </p>
                    <p style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: '0.5rem', color: 'var(--text-color)', marginBottom: '1rem' }}>
                      <Clock size={16} /> {booking.time_slot}
                    </p>
                    
                    <div style={{ 
                      display: 'inline-flex', alignItems: 'center', gap: '0.4rem', 
                      padding: '0.4rem 0.8rem', borderRadius: '999px', fontWeight: 'bold',
                      backgroundColor: isCompleted ? '#ecfdf5' : '#fef3c7',
                      color: isCompleted ? '#10b981' : '#d97706'
                    }}>
                      {isCompleted ? <CheckCircle size={16}/> : <Loader size={16}/>} 
                      {booking.status.toUpperCase()}
                    </div>
                  </div>
                </div>

                {/* Feedback Section */}
                {isCompleted && !hasFeedback && (
                  <div style={{ marginTop: '0.5rem', paddingTop: '1rem', borderTop: '1px dashed var(--border-color)' }}>
                    <h4 style={{ fontWeight: '600', marginBottom: '0.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                      <MessageSquare size={16} className="text-gradient"/> How was your experience?
                    </h4>
                    <div style={{ display: 'flex', gap: '0.25rem', marginBottom: '0.75rem' }}>
                      {[1, 2, 3, 4, 5].map(star => (
                        <button 
                          key={star} 
                          onClick={() => handleFeedbackChange(booking.id, 'rating', star)}
                          style={{ color: star <= fbInput.rating ? '#f59e0b' : '#d1d5db' }}
                        >
                          <Star size={24} fill={star <= fbInput.rating ? "currentColor" : "none"} />
                        </button>
                      ))}
                    </div>
                    <div style={{ display: 'flex', gap: '1rem' }}>
                      <input 
                        className="input-field" 
                        placeholder="Write a brief review..." 
                        value={fbInput.feedback}
                        onChange={(e) => handleFeedbackChange(booking.id, 'feedback', e.target.value)}
                        style={{ flex: 1 }}
                      />
                      <button className="btn btn-primary" onClick={() => submitFeedback(booking.id)}>Submit Review</button>
                    </div>
                  </div>
                )}

                {hasFeedback && (
                  <div style={{ marginTop: '0.5rem', paddingTop: '1rem', borderTop: '1px solid var(--border-color)' }}>
                    <div style={{ color: '#10b981', fontWeight: 'bold', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem', backgroundColor: '#ecfdf5', padding: '0.75rem', borderRadius: '0.5rem' }}>
                      <CheckCircle size={18} /> Thanks for sharing your valuable review!
                    </div>
                    <h4 style={{ fontSize: '0.875rem', color: 'var(--text-muted)', marginBottom: '0.5rem' }}>Your Submitted Review</h4>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', color: '#f59e0b', marginBottom: '0.25rem' }}>
                       {[...Array(booking.customer_rating)].map((_, i) => <Star key={i} size={14} fill="currentColor" />)}
                    </div>
                    <p style={{ fontStyle: 'italic', color: 'var(--text-color)' }}>"{booking.customer_feedback}"</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      ) : (
        <div className="glass-panel" style={{ textAlign: 'center', padding: '4rem' }}>
          <p style={{ color: 'var(--text-muted)', fontSize: '1.1rem' }}>You haven't booked any services yet.</p>
        </div>
      )}
    </div>
  );
}
