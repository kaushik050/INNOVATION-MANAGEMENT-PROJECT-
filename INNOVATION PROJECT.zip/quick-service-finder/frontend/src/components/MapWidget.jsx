import { useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Fix basic Leaflet marker icon asset paths breaking in Vite
import iconRetina from 'leaflet/dist/images/marker-icon-2x.png';
import iconUrl from 'leaflet/dist/images/marker-icon.png';
import shadowUrl from 'leaflet/dist/images/marker-shadow.png';

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: iconRetina,
  iconUrl: iconUrl,
  shadowUrl: shadowUrl,
});

// A small functional component inside the map to automatically pan/zoom to fit strictly the rendered pins.
function MapBoundsFitter({ services }) {
  const map = useMap();

  useEffect(() => {
    if (services && services.length > 0) {
      const bounds = L.latLngBounds(services.map(s => [s.lat, s.lng]));
      if (bounds.isValid()) {
        map.fitBounds(bounds, { padding: [50, 50], maxZoom: 14 });
      }
    }
  }, [services, map]);

  return null;
}

export default function MapWidget({ services }) {
  // Center defaults to India
  const center = [20.5937, 78.9629];
  const zoom = 5;

  return (
    <MapContainer 
      center={center} 
      zoom={zoom} 
      style={{ height: '100%', width: '100%', borderRadius: '1.5rem' }}
      scrollWheelZoom={false}
    >
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      
      {services.map(s => (
        s.lat && s.lng && (
          <Marker key={s.id} position={[s.lat, s.lng]}>
            <Popup>
              <div style={{ padding: '0.25rem' }}>
                <h3 style={{ fontSize: '1.1rem', margin: '0 0 0.5rem', fontWeight: 'bold' }}>{s.name}</h3>
                <span style={{ backgroundColor: 'var(--surface-hover)', padding: '0.2rem 0.5rem', borderRadius: '4px', fontSize: '0.8rem', color: 'var(--primary)' }}>
                  {s.type}
                </span>
                <p style={{ margin: '0.5rem 0 0', fontWeight: 'bold', color: 'var(--text-color)' }}>Starting at ₹{s.price}</p>
                <p style={{ margin: '0.2rem 0 0', color: 'var(--text-muted)' }}>{s.location}</p>
              </div>
            </Popup>
          </Marker>
        )
      ))}

      <MapBoundsFitter services={services} />
    </MapContainer>
  );
}
