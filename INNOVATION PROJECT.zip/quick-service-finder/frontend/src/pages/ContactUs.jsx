import { useState } from 'react';
import { Mail, Phone, MapPin, Send } from 'lucide-react';

export default function ContactUs() {
  const [formData, setFormData] = useState({
    name: '',
    title: '',
    message: ''
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const { name, title, message } = formData;
    const body = `Name: ${name}%0D%0A%0D%0A${message}`;
    window.location.href = `mailto:ys.kaushikreddy@gmail.com?subject=${encodeURIComponent(title)}&body=${body}`;
  };

  return (
    <div className="animate-fade-in" style={{ maxWidth: '900px', margin: '0 auto', paddingBottom: '4rem' }}>
      <div className="glass-panel" style={{ marginBottom: '2.5rem', textAlign: 'center' }}>
        <h1 style={{ fontSize: '2.5rem', marginBottom: '0.5rem', fontWeight: 'bold' }}>Contact Us</h1>
        <p style={{ color: 'var(--text-muted)' }}>Have an issue to report or need help? Get in touch with us.</p>
      </div>
      
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '2rem' }}>
        <div className="glass-panel">
          <h2 style={{ fontSize: '1.5rem', marginBottom: '1.5rem', fontWeight: 'bold' }}>Send a Message</h2>
          
          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <div>
              <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>Name</label>
              <input 
                type="text" 
                name="name" 
                value={formData.name} 
                onChange={handleChange} 
                className="input-field" 
                required 
              />
            </div>
            
            <div>
              <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>Title (Issue)</label>
              <input 
                type="text" 
                name="title" 
                value={formData.title} 
                onChange={handleChange} 
                className="input-field" 
                required 
              />
            </div>
            
            <div>
              <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>Message Details</label>
              <textarea 
                name="message" 
                value={formData.message} 
                onChange={handleChange} 
                className="input-field" 
                rows="5" 
                required 
              ></textarea>
            </div>
            
            <button type="submit" className="btn btn-primary" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem', marginTop: '0.5rem' }}>
              <Send size={18} /> Send via Email Client
            </button>
          </form>
        </div>
        
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          <div className="glass-panel" style={{ display: 'flex', alignItems: 'center', gap: '1.5rem', padding: '1.5rem' }}>
            <div style={{ backgroundColor: 'var(--surface-hover)', padding: '1rem', borderRadius: '50%', color: 'var(--primary)' }}>
              <Phone size={28} />
            </div>
            <div>
              <h3 style={{ fontWeight: 'bold', fontSize: '1.2rem', marginBottom: '0.25rem' }}>Phone Number</h3>
              <p style={{ color: 'var(--text-muted)', fontSize: '1.1rem' }}>8688882200</p>
            </div>
          </div>
          
          <div className="glass-panel" style={{ display: 'flex', alignItems: 'center', gap: '1.5rem', padding: '1.5rem' }}>
            <div style={{ backgroundColor: 'var(--surface-hover)', padding: '1rem', borderRadius: '50%', color: 'var(--primary)' }}>
              <Mail size={28} />
            </div>
            <div>
              <h3 style={{ fontWeight: 'bold', fontSize: '1.2rem', marginBottom: '0.25rem' }}>Email Address</h3>
              <p style={{ color: 'var(--text-muted)', fontSize: '1.1rem' }}>ys.kaushikreddy@gmail.com</p>
            </div>
          </div>
          
          <div className="glass-panel" style={{ display: 'flex', alignItems: 'center', gap: '1.5rem', padding: '1.5rem' }}>
            <div style={{ backgroundColor: 'var(--surface-hover)', padding: '1rem', borderRadius: '50%', color: 'var(--primary)' }}>
              <MapPin size={28} />
            </div>
            <div>
              <h3 style={{ fontWeight: 'bold', fontSize: '1.2rem', marginBottom: '0.25rem' }}>Location</h3>
              <p style={{ color: 'var(--text-muted)', fontSize: '1.1rem' }}>India, Hyderabad</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
